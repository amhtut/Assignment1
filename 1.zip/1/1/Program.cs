﻿using System;

namespace Application
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            double HEIGHT = 0;
            Console.WriteLine("Please enter your first name. ");
            var FIRSTNAME = Console.ReadLine();

            Console.WriteLine("Please enter your last name. ");
            var LASTNAME = Console.ReadLine();

            string FULLNAME = FIRSTNAME + " " + LASTNAME;

            Console.WriteLine("Please enter your height in inches(in). ");
            HEIGHT = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Please enter your weight in pounds(lb). ");
            double WEIGHT = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nHello " + FULLNAME + ",\nYour height is: " + HEIGHT + "in \nYour weight is: " + WEIGHT + "lbs.");

            double formula1 = HEIGHT * HEIGHT;
            double formula2 = (WEIGHT * formula1) / 703;

            Console.WriteLine("Your BMI is: " + formula2 + ".");
        }
    }
}